# Hangman
A small game of Hangman I made from scratch using the Godot game engine.

To play, you could use the default words I've set it up with or input your own in word.gd located in the scenes folder.

(Image credit goes to SpiralGeass: https://www.deviantart.com/spiralgeass)